# Wendigo Enemy
Wendigo monster that spawns in the facility 